#!/usr/bin/env python3
import argparse, json, os, math
from pathlib import Path
from typing import List, Dict, Any

import torch
from datasets import Dataset, concatenate_datasets
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainingArguments,
    set_seed,
)

# Optional (LoRA)
from peft import LoraConfig, get_peft_model


def read_jsonl(path: str) -> List[Dict[str, Any]]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
    return data


def to_messages(record: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Normalizes a variety of shapes into a messages list:
      - {'messages': [...]}  (preferred)
      - {'system': str, 'messages': [...]} (system merged)
      - {'input': '...', 'output': '...'}  (simple QA)
    """
    if "messages" in record and isinstance(record["messages"], list):
        msgs = record["messages"]
        system = record.get("system")
        if system:
            msgs = [{"role": "system", "content": system}] + msgs
        return msgs

    if "input" in record and "output" in record:
        return [
            {"role": "user", "content": str(record["input"])},
            {"role": "assistant", "content": str(record["output"])},
        ]

    # Fallback: try to guess common fields
    for k in ("prompt", "question", "instruction"):
        if k in record:
            u = str(record[k])
            a = str(record.get("answer", record.get("response", "")))
            return [{"role": "user", "content": u}] + (
                [{"role": "assistant", "content": a}] if a else []
            )

    # If nothing matches, treat as a single message blob
    return [{"role": "user", "content": json.dumps(record, ensure_ascii=False)}]


def build_text(tokenizer, messages: List[Dict[str, str]]) -> str:
    """
    Build a single training example text using chat template if available.
    We train causal LM on the full conversation transcript (no special labels mask).
    """
    if hasattr(tokenizer, "apply_chat_template") and (tokenizer.chat_template is not None):
        return tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=False
        )
    # Safe fallback template for Llama-like chat
    out = []
    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if role == "system":
            out.append(f"<|system|>\n{content}\n")
        elif role == "user":
            out.append(f"<|user|>\n{content}\n")
        else:
            out.append(f"<|assistant|>\n{content}\n")
    out.append(tokenizer.eos_token or "")
    return "".join(out)


def load_and_format(tokenizer, jsonl_paths: List[str]) -> Dataset:
    dsets = []
    for p in jsonl_paths:
        rows = read_jsonl(p)
        # Map to normalized text
        texts = []
        for r in rows:
            msgs = to_messages(r)
            txt = build_text(tokenizer, msgs)
            if txt and txt.strip():
                texts.append({"text": txt})
        dsets.append(Dataset.from_list(texts))
    return concatenate_datasets(dsets) if len(dsets) > 1 else dsets[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="HF model id or local path")
    ap.add_argument("--train_jsonl", nargs="+", required=True, help="One or more JSONL files")
    ap.add_argument("--output_dir", required=True)

    # Training hyperparams
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--batch_size", type=int, default=1, help="per-device train batch size")
    ap.add_argument("--grad_accum", type=int, default=8)
    ap.add_argument("--warmup_ratio", type=float, default=0.03)
    ap.add_argument("--max_steps", type=int, default=-1)

    ap.add_argument("--max_seq_len", type=int, default=2048)
    ap.add_argument("--bf16", action="store_true")
    ap.add_argument("--fp16", action="store_true")
    ap.add_argument("--tf32", action="store_true")
    ap.add_argument("--packing", action="store_true", help="(placeholder)")

    ap.add_argument("--gradient_checkpointing", action="store_true")
    ap.add_argument("--seed", type=int, default=42)

    ap.add_argument("--save_steps", type=int, default=500)
    ap.add_argument("--logging_steps", type=int, default=10)
    ap.add_argument("--eval_steps", type=int, default=0, help="No-op unless you wire eval_dataset")
    ap.add_argument("--eval_holdout", default=None, help="(optional) JSONL to eval")

    ap.add_argument("--report_to", default="none")

    # LoRA options (if r>0, we enable it)
    ap.add_argument("--lora_r", type=int, default=0, help=">0 enables LoRA")
    ap.add_argument("--lora_alpha", type=int, default=16)
    ap.add_argument("--lora_dropout", type=float, default=0.05)
    ap.add_argument(
        "--target_modules",
        nargs="+",
        default=[],
        help="e.g. q_proj k_proj v_proj o_proj up_proj down_proj gate_proj",
    )

    args = ap.parse_args()
    set_seed(args.seed)

    if args.tf32:
        try:
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.set_float32_matmul_precision("high")
        except Exception:
            pass

    # Tokenizer
    tok = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    # Dataset → tokenized
    train_ds_text = load_and_format(tok, args.train_jsonl)

    def tokenize_fn(batch):
        return tok(
            batch["text"],
            truncation=True,
            max_length=args.max_seq_len,
            padding=False,
            return_attention_mask=True,
        )

    train_ds = train_ds_text.map(tokenize_fn, batched=True, remove_columns=["text"])
    # Optional simple packing (concat chunks) could be added later; we keep it straightforward.

    # Model
    dtype = torch.bfloat16 if args.bf16 else (torch.float16 if args.fp16 else torch.float32)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map="auto",
        low_cpu_mem_usage=True,
    )

    if args.gradient_checkpointing:
        model.gradient_checkpointing_enable()

    # LoRA
    if args.lora_r and args.lora_r > 0:
        target = args.target_modules or ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
        lcfg = LoraConfig(
            r=args.lora_r,
            lora_alpha=args.lora_alpha,
            lora_dropout=args.lora_dropout,
            target_modules=target,
            bias="none",
            task_type="CAUSAL_LM",
        )
        model = get_peft_model(model, lcfg)
        model.print_trainable_parameters()

    # Collator (classic causal LM)
    data_collator = DataCollatorForLanguageModeling(tokenizer=tok, mlm=False)

    # Training args
    total_steps = args.max_steps if args.max_steps and args.max_steps > 0 else None
    training_args = TrainingArguments(
        output_dir=args.output_dir,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        learning_rate=args.lr,
        num_train_epochs=0 if total_steps else args.epochs,
        max_steps=total_steps if total_steps else -1,
        warmup_ratio=args.warmup_ratio,
        logging_steps=args.logging_steps,
        save_steps=args.save_steps,
        bf16=args.bf16,
        fp16=args.fp16 and (not args.bf16),
        report_to=None if args.report_to == "none" else args.report_to,
        gradient_checkpointing=args.gradient_checkpointing,
        lr_scheduler_type="cosine",
        optim="adamw_torch",
    )

    trainer = Trainer(
        model=model,
        tokenizer=tok,
        args=training_args,
        train_dataset=train_ds,
        data_collator=data_collator,
    )

    # Allow PyTorch to use expandable segments to combat fragmentation
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

    trainer.train()
    trainer.save_model(args.output_dir)
    if hasattr(tok, "save_pretrained"):
        tok.save_pretrained(args.output_dir)


if __name__ == "__main__":
    main()

